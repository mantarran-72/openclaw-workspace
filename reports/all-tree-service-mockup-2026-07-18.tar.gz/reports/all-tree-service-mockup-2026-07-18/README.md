# All Tree Service mockup

Open `index.html` in a browser. Keep the `assets/` folder next to it so the photos and logo load.

Notes:
- No "Certified Arborist" claim is used.
- Bathroom screenshots were intentionally excluded.
- Phone: 707-843-2333
- License: #1111482
