# Shelina Pabani Consulting - Homepage / Contact Rebuild Notes

Goal from inquiry: **More requests**

## What the current site already has

- Strong credibility and relevant experience.
- Clear service domain: leadership and employee development consulting.
- Useful proof: testimonials, clients, partnerships, and facilitator feedback.
- Existing Squarespace site structure that can be reused or migrated.

## Main conversion issue

The current site reads like a credibility brochure. It explains Shelina's background and offerings, but it does not strongly guide a visitor toward a specific inquiry action.

For someone looking for leadership training, manager development, or a team offsite, the site should quickly answer:

- Is this for my type of organization?
- What kind of problem can Shelina help with?
- What is the next step?
- What information should I send to start the conversation?

## Changes shown in the mockup

1. Stronger homepage headline

   The new hero moves from general description to an outcome-driven promise:

   **Build stronger managers, clearer teams, and more confident leaders.**

   This makes the value easier to understand quickly.

2. Clearer service paths

   The current site lists many programs and topics. The mockup groups them into buyer-friendly categories:

   - New manager and leadership development
   - Team offsites and executive alignment
   - Custom learning strategy and programs

   This lets a visitor self-identify faster.

3. Stronger proof placement

   Shelina already has good testimonials and participant feedback. The mockup brings this proof higher on the page so it supports the decision to inquire.

4. Better positioning of Shelina's background

   The existing Apple, Walmart.com, and Prosper experience is valuable. The mockup presents this as a reason to trust her with corporate learning needs, not just as biography.

5. Contact section rebuilt around qualified requests

   Instead of a generic contact form, the new contact flow asks about:

   - organization
   - type of support needed
   - audience/challenge/timeline/outcome

   This should help produce better requests and make the first follow-up conversation more useful.

## Recommended first phase

A focused homepage/contact rebuild is the best first step.

Included:

- Homepage rewrite and visual redesign.
- Updated service framing.
- Stronger inquiry calls to action.
- Rebuilt contact/request flow.
- Mobile cleanup.
- Basic SEO/share metadata cleanup.

This avoids overbuilding while directly addressing the stated goal: more requests.

